﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.IO; // Dosya işlemleri için gerekli

namespace DeuEeChess
{
    class Program
    {
        // --- 1. SABİTLER VE YAPILAR ---

        //renkleri temsil eden enum yapısı. 0:yok, 1:beyaz, 2:siyah
        enum PieceColor { None, White, Black }

        //taş tiplerini belirten enum. kodun okunabilirliğini artırır
        enum PieceType { Empty, Pawn, Rook, Knight, Bishop, Queen, King }

        //bir satranç taşının tüm özelliklerini tutan yapı
        //class yerine struct kullandık çünkü taşlar basit veri yapılarıdır, bellekte az yer kaplar
        struct Piece
        {
            public PieceType Type;   //taşın türü (kale, piyon vb.)
            public PieceColor Color; //taşın rengi
            public char Symbol;      //ekranda görünecek karakter (K, Q, R vb.)
            public bool HasMoved;    //rok yapabilmek için taşın daha önce oynayıp oynamadığını tutar
        }

        //hamle verisini tutan yardımcı yapı
        struct Move
        {
            public int FromRow, FromCol, ToRow, ToCol;
        }

        // --- 2. GLOBAL DEĞİŞKENLER ---

        //8x8'lik satranç tahtası matrisi. her kare bir 'Piece' yapısı tutar
        static Piece[,] board = new Piece[8, 8];

        //sıranın kimde olduğunu tutan değişken. varsayılan beyaz başlar
        static PieceColor currentTurn = PieceColor.White;

        //oyun geçmişini tutan liste (örn: "e4", "e5", "Nf3")
        static List<string> moveHistory = new List<string>();

        //pdf'teki örnek maç hamleleri
        static string[] demoGameMoves = new string[]
        {
            "e4", "e5",
            "Nf3", "Nf6",
            "d4", "exd4",
            "e5", "Ne4",
            "Qxd4", "d5",
            "exd6", "Nxd6",
            "Bg5", "Nc6",
            "Qe3", "Be7",
            "Nbd2", "O-O",
            "O-O-O", "Re8",
            "Kb1"
        };

        static void Main(string[] args)
        {
            //konsol pencere başlığı ve karakter kodlaması ayarları
            Console.Title = "DEU-EE Chess 2025 - FINAL PROJECT";
            Console.OutputEncoding = System.Text.Encoding.UTF8;

            //sonsuz döngü ile menü sistemi
            while (true)
            {
                //her yeni oyunda tahtayı ve geçmişi sıfırla (eğer yükleme yapılmazsa)
                if (currentTurn == PieceColor.White && moveHistory.Count == 0) InitBoard();

                Console.Clear();
                Console.WriteLine("==========================================");
                Console.WriteLine("       DEU-EE CHESS 2025 (FINAL)");
                Console.WriteLine("==========================================");
                Console.WriteLine("1. Play Mode (Oyna)");
                Console.WriteLine("2. Demo Mode (İzle)");
                Console.WriteLine("3. Load Game (Kayıtlı Oyunu Yükle)"); // YENİ
                Console.WriteLine("Q. Çıkış");
                Console.WriteLine("==========================================");
                Console.Write("Seçiminiz: ");
                string choice = Console.ReadLine();

                if (choice == "1")
                {
                    // Yeni oyun başlatıyorsak temizle
                    if (moveHistory.Count > 0)
                    {
                        Console.Write("Mevcut oyunu sıfırla? (e/h): ");
                        if (Console.ReadLine().ToLower() == "e") { InitBoard(); moveHistory.Clear(); currentTurn = PieceColor.White; }
                    }
                    else { InitBoard(); moveHistory.Clear(); currentTurn = PieceColor.White; }

                    RunPlayMode();
                }
                else if (choice == "2")
                {
                    InitBoard(); moveHistory.Clear(); currentTurn = PieceColor.White;
                    RunDemoMode();
                }
                else if (choice == "3") // YENİ: YÜKLEME
                {
                    if (LoadGame())
                    {
                        Console.WriteLine("Oyun başarıyla yüklendi! Play Mode'a geçiliyor...");
                        Thread.Sleep(1000);
                        RunPlayMode();
                    }
                    else
                    {
                        Console.WriteLine("Kayıt dosyası bulunamadı veya hatalı.");
                        Console.ReadKey();
                    }
                }
                else if (choice.ToLower() == "q") break;
            }
        }

        // --- 3. MODLAR ---

        //kullanıcının oynadığı mod
        static void RunPlayMode()
        {
            while (true)
            {
                Console.Clear();
                DrawBoard(); // Artık hamle listesini de çizer
                PrintTurnInfo();

                //kendi şahımız tehdit altında mı kontrolü
                if (IsKingInCheck(currentTurn))
                {
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("\n!!! DİKKAT: ŞAH (CHECK) !!!");
                    Console.ResetColor();
                }

                Console.WriteLine("Komutlar: Hamle (e4, Nf3), İpucu (h), Kaydet (s), Çıkış (q)");
                Console.Write("Hamle: ");
                string input = Console.ReadLine();

                if (input.ToLower() == "q") break;

                // KAYDETME KOMUTU
                if (input.ToLower() == "s")
                {
                    SaveGame();
                    Console.WriteLine("\nOyun 'chess_save.txt' dosyasına kaydedildi.");
                    Console.WriteLine("Devam etmek için bir tuşa basın...");
                    Console.ReadKey();
                    continue;
                }

                //ipucu özelliği: 'h' tuşuna basınca olası yeme hamlelerini gösterir
                if (input.ToLower() == "h")
                {
                    ShowCaptureHints();
                    Console.WriteLine("\nDevam etmek için bir tuşa basın...");
                    Console.ReadKey();
                    continue;
                }

                //hamleyi işlemeye çalış, başarılıysa sırayı değiştir
                if (ProcessMove(input))
                {
                    // Başarılı hamleyi listeye ekle (input olarak ne girildiyse)
                    // Not: Daha şık olması için burada SAN'a çevrilebilirdi ama şimdilik input'u ekliyoruz
                    moveHistory.Add(input);
                    SwitchTurn();
                }
                else
                {
                    Console.WriteLine("Geçersiz hamle! (Tuşa bas...)");
                    Console.ReadKey();
                }
            }
        }

        //dosyadan (arrayden) okuyarak otomatik oynatma modu
        static void RunDemoMode()
        {
            int moveIndex = 0;
            Console.WriteLine("Demo Modu Başlatılıyor... İlerlemek için SPACE, çıkmak için Q basın.");
            Thread.Sleep(1000);

            //hamle listesi bitene kadar döngü
            while (moveIndex < demoGameMoves.Length)
            {
                Console.Clear();
                DrawBoard();

                string sanMove = demoGameMoves[moveIndex];

                if (IsKingInCheck(currentTurn))
                {
                    Console.WriteLine("\n!!! ŞAH !!!");
                }

                Console.WriteLine($"\nDemo Hamlesi ({currentTurn}): {sanMove}");
                Console.WriteLine("Devam etmek için SPACE'e basın...");

                //tuş okuma
                var key = Console.ReadKey(true).Key;
                if (key == ConsoleKey.Q) return;
                if (key != ConsoleKey.Spacebar) continue; //sadece space ile ilerle

                if (ProcessMove(sanMove))
                {
                    moveHistory.Add(sanMove); // Demoda hamleleri de listeye ekleyelim
                    SwitchTurn();
                    moveIndex++;
                }
                else
                {
                    Console.WriteLine($"HATA: Demo dosyasındaki hamle ({sanMove}) işlenemedi!");
                    Console.ReadKey();
                    return;
                }
            }

            Console.Clear();
            DrawBoard();
            Console.WriteLine("\nDemo Maç Bitti! Menüye dönülüyor...");
            Console.ReadKey();
        }

        // --- YENİ: KAYDET VE YÜKLE (FILE I/O) ---

        static void SaveGame()
        {
            try
            {
                using (StreamWriter sw = new StreamWriter("chess_save.txt"))
                {
                    // 1. Sıra kimde
                    sw.WriteLine(currentTurn == PieceColor.White ? "White" : "Black");

                    // 2. Hamle Geçmişi (Tek satırda virgülle ayrılmış)
                    sw.WriteLine(string.Join(",", moveHistory));

                    // 3. Tahta Durumu
                    // Format: Satır,Sütun,Tip,Renk,HasMoved
                    for (int r = 0; r < 8; r++)
                    {
                        for (int c = 0; c < 8; c++)
                        {
                            Piece p = board[r, c];
                            if (p.Type != PieceType.Empty)
                            {
                                int typeInt = (int)p.Type;
                                int colorInt = (int)p.Color;
                                sw.WriteLine($"{r},{c},{typeInt},{colorInt},{p.HasMoved}");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Kaydetme hatası: " + ex.Message);
            }
        }

        static bool LoadGame()
        {
            if (!File.Exists("chess_save.txt")) return false;

            try
            {
                string[] lines = File.ReadAllLines("chess_save.txt");
                if (lines.Length < 3) return false;

                // Tahtayı temizle
                for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) board[r, c] = CreatePiece(PieceType.Empty, PieceColor.None);

                // 1. Sıra
                currentTurn = lines[0] == "White" ? PieceColor.White : PieceColor.Black;

                // 2. Geçmiş
                moveHistory.Clear();
                if (!string.IsNullOrWhiteSpace(lines[1]))
                {
                    string[] moves = lines[1].Split(',');
                    moveHistory.AddRange(moves);
                }

                // 3. Taşlar
                for (int i = 2; i < lines.Length; i++)
                {
                    string[] parts = lines[i].Split(',');
                    if (parts.Length == 5)
                    {
                        int r = int.Parse(parts[0]);
                        int c = int.Parse(parts[1]);
                        PieceType type = (PieceType)int.Parse(parts[2]);
                        PieceColor color = (PieceColor)int.Parse(parts[3]);
                        bool hasMoved = bool.Parse(parts[4]);

                        board[r, c] = CreatePiece(type, color);
                        board[r, c].HasMoved = hasMoved; // CreatePiece false yapar, buradan güncelliyoruz
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        // --- YENİ: İPUCU FONKSİYONU ---
        //rakip taşı yiyebilecek tüm hamleleri tarayan fonksiyon
        static void ShowCaptureHints()
        {
            Console.WriteLine("\n--- İPUÇLARI (Yeme İhtimalleri) ---");
            bool found = false;

            //tüm tahtayı (8x8) iç içe döngülerle tara
            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    //sadece sırası gelen oyuncunun taşlarına bak
                    Piece p = board[r, c];
                    if (p.Color == currentTurn)
                    {
                        //bu taşın gidebileceği tüm hedef kareleri kontrol et
                        for (int tr = 0; tr < 8; tr++)
                        {
                            for (int tc = 0; tc < 8; tc++)
                            {
                                //eğer hamle kurallara uygunsa VE hedefte rakip varsa
                                if (IsMoveValid(r, c, tr, tc))
                                {
                                    Piece target = board[tr, tc];
                                    if (target.Type != PieceType.Empty && target.Color != p.Color)
                                    {
                                        //simülasyon: hamleyi yapıp şahın güvende olup olmadığına bakmalıyız
                                        Piece tempTarget = board[tr, tc];
                                        board[tr, tc] = p;
                                        board[r, c] = CreatePiece(PieceType.Empty, PieceColor.None);

                                        bool isSafe = !IsKingInCheck(currentTurn);

                                        //tahtayı eski haline getir (geri al)
                                        board[r, c] = p;
                                        board[tr, tc] = tempTarget;

                                        //eğer hamle güvenliyse ekrana yazdır
                                        if (isSafe)
                                        {
                                            string from = $"{(char)('a' + c)}{8 - r}";
                                            string to = $"{(char)('a' + tc)}{8 - tr}";
                                            Console.WriteLine($"* {p.Symbol} ({from}) -> {target.Symbol} yiyebilir ({to})");
                                            found = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (!found) Console.WriteLine("Rakip taşı yiyebilecek bir hamle bulunamadı.");
        }

        // --- 4. HAMLE İŞLEME VE NOTASYON ÇÖZME ---

        //giriş stringini (e2 e4 veya Nf3) işleyen ana fonksiyon
        static bool ProcessMove(string input)
        {
            if (string.IsNullOrWhiteSpace(input)) return false;

            int fR, fC, tR, tC;

            //giriş türünü anla: koordinat mı (e2 e4) yoksa notasyon mu (Nf3)?
            if (input.Contains(" ") && input.Length >= 5 && !input.Contains("O-O"))
            {
                //eski usül koordinat girişi
                string[] parts = input.Split(' ');
                if (!ParsePosition(parts[0], out fR, out fC) || !ParsePosition(parts[1], out tR, out tC))
                    return false;
            }
            else
            {
                //cebirsel notasyon (SAN) çözümü
                if (!ConvertSanToMove(input, currentTurn, out fR, out fC, out tR, out tC))
                {
                    if (!RunPlayModeCheckSilent()) Console.WriteLine("Hamle çözülemedi.");
                    return false;
                }
            }

            //1. fiziksel kuralları kontrol et (taş hareketi doğru mu?)
            if (!ValidateBasicRules(fR, fC, tR, tC)) return false;

            //2. güvenlik kontrolü: hamle yapınca kendi şahımız tehlikeye giriyor mu?
            Piece originalMover = board[fR, fC];
            Piece originalTarget = board[tR, tC];

            //geçici hamle yap
            board[tR, tC] = originalMover;
            board[fR, fC] = CreatePiece(PieceType.Empty, PieceColor.None);

            //kontrol et
            bool isSelfCheck = IsKingInCheck(currentTurn);

            //geri al (undo)
            board[fR, fC] = originalMover;
            board[tR, tC] = originalTarget;

            if (isSelfCheck)
            {
                Console.WriteLine("HATA: Bu hamle şahınızı tehlikeye atıyor! (Illegal Move)");
                return false;
            }

            //3. her şey tamamsa hamleyi kalıcı olarak uygula
            return ExecuteMove(fR, fC, tR, tC);
        }

        //yardımcı metot: hata mesajlarını demo modunda gizlemek için
        static bool RunPlayModeCheckSilent() { return false; }

        //temel taş hareket kuralları validasyonu
        static bool ValidateBasicRules(int fR, int fC, int tR, int tC)
        {
            Piece movingPiece = board[fR, fC];
            Piece targetPiece = board[tR, tC];

            //kaynak kare boş mu?
            if (movingPiece.Type == PieceType.Empty) return false;
            //sıra o renkte mi?
            if (movingPiece.Color != currentTurn) return false;
            //hedefte kendi taşımız var mı?
            if (targetPiece.Color == currentTurn) return false;

            //taşın özel hareket kuralına (delta hesabı) uyuyor mu?
            return IsMoveValid(fR, fC, tR, tC);
        }

        // --- ŞAH KONTROL MEKANİZMASI ---

        //verilen rengin şahı tehdit altında mı diye kontrol eder
        static bool IsKingInCheck(PieceColor kingColor)
        {
            //1. adım: şahın tahtadaki yerini (kR, kC) bul
            int kR = -1, kC = -1;
            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (board[r, c].Type == PieceType.King && board[r, c].Color == kingColor)
                    {
                        kR = r; kC = c;
                        break;
                    }
                }
            }
            if (kR == -1) return false; //şah bulunamazsa (hata durumu)

            //2. adım: tüm rakip taşları gez ve şahı yiyebiliyorlar mı diye bak
            PieceColor enemyColor = (kingColor == PieceColor.White) ? PieceColor.Black : PieceColor.White;

            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (board[r, c].Color == enemyColor)
                    {
                        //eğer rakip taş şahın karesine gidebiliyorsa şah çekiliyordur
                        if (IsMoveValid(r, c, kR, kC))
                            return true;
                    }
                }
            }
            return false;
        }

        //notasyonu (örn: Nf3) koordinata (örn: g1 -> f3) çeviren algoritma
        static bool ConvertSanToMove(string san, PieceColor color, out int fR, out int fC, out int tR, out int tC)
        {
            fR = -1; fC = -1; tR = -1; tC = -1;
            //gereksiz karakterleri temizle (+: şah, #: mat, x: yeme)
            san = san.Replace("+", "").Replace("#", "").Replace("x", "").Trim();

            //rok kontrolü (özel durum)
            if (san == "O-O" || san == "0-0") //kısa rok
            {
                fR = (color == PieceColor.White) ? 7 : 0; fC = 4; tR = fR; tC = 6;
                return IsMoveValid(fR, fC, tR, tC);
            }
            if (san == "O-O-O" || san == "0-0-0") //uzun rok
            {
                fR = (color == PieceColor.White) ? 7 : 0; fC = 4; tR = fR; tC = 2;
                return IsMoveValid(fR, fC, tR, tC);
            }

            if (san.Length < 2) return false;

            //hedef kareyi bul (son 2 karakter, örn: f3)
            string targetStr = san.Substring(san.Length - 2);
            if (!ParsePosition(targetStr, out tR, out tC)) return false;

            //hangi taş tipi oynuyor? (büyük harfle başlar, piyon hariç)
            PieceType type = PieceType.Pawn;
            char firstChar = san[0];
            if (char.IsUpper(firstChar))
            {
                switch (firstChar)
                {
                    case 'R': type = PieceType.Rook; break;
                    case 'N': type = PieceType.Knight; break;
                    case 'B': type = PieceType.Bishop; break;
                    case 'Q': type = PieceType.Queen; break;
                    case 'K': type = PieceType.King; break;
                }
            }

            //aday taşları bul: kim bu hedefe gidebilir?
            List<Move> candidates = new List<Move>();
            for (int r = 0; r < 8; r++)
            {
                for (int c = 0; c < 8; c++)
                {
                    Piece p = board[r, c];
                    if (p.Color == color && p.Type == type)
                    {
                        //eğer bu taş hedefe gidebiliyorsa
                        if (IsMoveValid(r, c, tR, tC))
                        {
                            //simülasyon yap: bu hamle şahı açıkta bırakıyor mu? (pinned piece)
                            Piece originalTarget = board[tR, tC];
                            board[tR, tC] = p;
                            board[r, c] = CreatePiece(PieceType.Empty, PieceColor.None);
                            bool causesSelfCheck = IsKingInCheck(color);
                            //geri al
                            board[r, c] = p;
                            board[tR, tC] = originalTarget;

                            if (!causesSelfCheck)
                                candidates.Add(new Move { FromRow = r, FromCol = c, ToRow = tR, ToCol = tC });
                        }
                    }
                }
            }

            //hiç aday yoksa veya birden fazla aday varsa
            if (candidates.Count == 0) return false;
            if (candidates.Count == 1)
            {
                fR = candidates[0].FromRow; fC = candidates[0].FromCol;
                return true;
            }

            //belirsizlik çözme (disambiguation): örn Nbd2 (b sütunundaki at)
            char hint = ' ';
            if (char.IsUpper(san[0])) { if (san.Length > 3) hint = san[1]; }
            else { if (san.Length > 2) hint = san[0]; } //piyon durumu (exd5)

            foreach (var move in candidates)
            {
                bool match = true;
                if (hint != ' ')
                {
                    if (hint >= 'a' && hint <= 'h') { if (move.FromCol != (hint - 'a')) match = false; }
                    else if (hint >= '1' && hint <= '8') { if (move.FromRow != (8 - (hint - '0'))) match = false; }
                }
                if (match) { fR = move.FromRow; fC = move.FromCol; return true; }
            }
            return false;
        }

        //hamleyi tahtada fiziksel olarak uygulayan fonksiyon
        static bool ExecuteMove(int fromRow, int fromCol, int toRow, int toCol)
        {
            Piece movingPiece = board[fromRow, fromCol];
            Piece targetPiece = board[toRow, toCol];

            //rok hareketi: şah 2 kare yana gidiyorsa kaleyi de taşı
            if (movingPiece.Type == PieceType.King && Math.Abs(toCol - fromCol) == 2)
            {
                bool isKingside = (toCol > fromCol);
                int rookFromCol = isKingside ? 7 : 0;
                int rookToCol = isKingside ? 5 : 3;
                Piece rook = board[fromRow, rookFromCol];

                board[fromRow, rookToCol] = rook;
                board[fromRow, rookToCol].HasMoved = true;
                board[fromRow, rookFromCol] = CreatePiece(PieceType.Empty, PieceColor.None);
            }

            //geçerken alma (en passant) kontrolü: piyon çapraz gidiyor ama hedef boş
            if (movingPiece.Type == PieceType.Pawn && targetPiece.Type == PieceType.Empty && fromCol != toCol)
            {
                //arkadaki piyonu kaldır
                board[fromRow, toCol] = CreatePiece(PieceType.Empty, PieceColor.None);
            }

            //ana taşıma işlemi
            board[toRow, toCol] = movingPiece;
            board[toRow, toCol].HasMoved = true; //taş oynadı olarak işaretle
            board[fromRow, fromCol] = CreatePiece(PieceType.Empty, PieceColor.None); //eski yeri boşalt

            //piyon terfisi (promotion): son satıra ulaşınca vezir yap
            if (movingPiece.Type == PieceType.Pawn)
            {
                if ((movingPiece.Color == PieceColor.White && toRow == 0) ||
                    (movingPiece.Color == PieceColor.Black && toRow == 7))
                {
                    board[toRow, toCol].Type = PieceType.Queen;
                    board[toRow, toCol].Symbol = 'Q';
                }
            }

            return true;
        }

        static void SwitchTurn()
        {
            currentTurn = (currentTurn == PieceColor.White) ? PieceColor.Black : PieceColor.White;
        }

        static void PrintTurnInfo()
        {
            Console.WriteLine("\n--- OYUN KONTROL ---");
            if (currentTurn == PieceColor.White) Console.WriteLine("Sıra: BEYAZ (Mavi)");
            else Console.WriteLine("Sıra: SİYAH (Kırmızı)");
        }

        //taşların hareket kurallarını matematiksel olarak kontrol eden fonksiyon
        static bool IsMoveValid(int r1, int c1, int r2, int c2)
        {
            Piece p = board[r1, c1];
            //delta (değişim) hesapları
            int dRow = r2 - r1; //satır farkı
            int dCol = c2 - c1; //sütun farkı
            int absRow = Math.Abs(dRow);
            int absCol = Math.Abs(dCol);

            switch (p.Type)
            {
                case PieceType.Pawn:
                    //yön hesabı: beyaz yukarı (-1), siyah aşağı (+1) gider
                    int direction = (p.Color == PieceColor.White) ? -1 : 1;

                    //normal hareket: 1 ileri
                    if (dCol == 0 && dRow == direction) return board[r2, c2].Type == PieceType.Empty;

                    //ilk hamle: 2 ileri
                    if (dCol == 0 && dRow == 2 * direction)
                    {
                        int startRow = (p.Color == PieceColor.White) ? 6 : 1;
                        if (r1 != startRow) return false;
                        //yol kontrolü: hem gidilen yer hem arası boş olmalı
                        if (board[r2, c2].Type != PieceType.Empty || board[r1 + direction, c1].Type != PieceType.Empty) return false;
                        return true;
                    }

                    //yeme hareketi: 1 ileri çapraz
                    if (absCol == 1 && dRow == direction)
                    {
                        if (board[r2, c2].Type != PieceType.Empty && board[r2, c2].Color != p.Color) return true;
                        return false;
                    }
                    return false;

                case PieceType.Rook:
                    //kale: sadece yatay veya dikey (biri 0 olmalı)
                    if (dRow != 0 && dCol != 0) return false;
                    return IsPathClear(r1, c1, r2, c2); //yol temiz mi?

                case PieceType.Bishop:
                    //fil: sadece çapraz (satır farkı == sütun farkı)
                    if (absRow != absCol) return false;
                    return IsPathClear(r1, c1, r2, c2);

                case PieceType.Queen:
                    //vezir: ya kale gibi ya fil gibi hareket eder
                    if (!(dRow == 0 || dCol == 0) && !(absRow == absCol)) return false;
                    return IsPathClear(r1, c1, r2, c2);

                case PieceType.King:
                    //şah: her yöne 1 kare
                    if (absRow <= 1 && absCol <= 1) return true;
                    //rok kontrolü: yan yana 2 kare
                    if (dRow == 0 && absCol == 2)
                    {
                        if (p.HasMoved) return false; //şah oynamışsa rok yapılamaz
                        bool isKingside = (dCol > 0);
                        int rookCol = isKingside ? 7 : 0;
                        Piece rook = board[r1, rookCol];
                        if (rook.Type != PieceType.Rook || rook.HasMoved) return false; //kale oynamışsa yapılamaz
                        return IsPathClear(r1, c1, r1, rookCol); //arası boş mu?
                    }
                    return false;

                case PieceType.Knight:
                    //at: L hareketi (2'ye 1 veya 1'e 2). yol kontrolü yapılmaz (üstten atlar)
                    return (absRow == 2 && absCol == 1) || (absRow == 1 && absCol == 2);

                default: return false;
            }
        }

        //iki kare arasındaki yolun boş olup olmadığını kontrol eder
        static bool IsPathClear(int r1, int c1, int r2, int c2)
        {
            //yön birimlerini bul (-1, 0 veya 1)
            int rowDir = Math.Sign(r2 - r1);
            int colDir = Math.Sign(c2 - c1);

            int r = r1 + rowDir;
            int c = c1 + colDir;

            //hedefe ulaşana kadar ilerle
            while (r != r2 || c != c2)
            {
                if (board[r, c].Type != PieceType.Empty) return false; //yolda taş var
                r += rowDir; c += colDir;
            }
            return true;
        }

        //string koordinatı (örn "e2") dizi indeksine çeviren metot
        static bool ParsePosition(string pos, out int row, out int col)
        {
            row = -1; col = -1;
            if (pos.Length != 2) return false;
            char file = pos[0]; char rank = pos[1];
            //'a' karakterini 0, 'b'yi 1 yapmak için ascii çıkarma işlemi
            if (file >= 'a' && file <= 'h') col = file - 'a';
            //satrançta 1. satır en alttır, dizide 7. indekse denk gelir
            if (rank >= '1' && rank <= '8') row = 8 - (rank - '0');
            return (row != -1 && col != -1);
        }

        //tahtayı başlangıç pozisyonuna getiren metot
        static void InitBoard()
        {
            //tüm kareleri temizle
            for (int r = 0; r < 8; r++) for (int c = 0; c < 8; c++) board[r, c] = CreatePiece(PieceType.Empty, PieceColor.None);

            //siyah taşlar (üstte)
            for (int i = 0; i < 8; i++) board[1, i] = CreatePiece(PieceType.Pawn, PieceColor.Black);
            SetupMainPieces(0, PieceColor.Black);

            //beyaz taşlar (altta)
            for (int i = 0; i < 8; i++) board[6, i] = CreatePiece(PieceType.Pawn, PieceColor.White);
            SetupMainPieces(7, PieceColor.White);
        }

        //ana taşları (kale, at, fil...) ilgili satıra dizer
        static void SetupMainPieces(int row, PieceColor color)
        {
            board[row, 0] = CreatePiece(PieceType.Rook, color); board[row, 1] = CreatePiece(PieceType.Knight, color);
            board[row, 2] = CreatePiece(PieceType.Bishop, color); board[row, 3] = CreatePiece(PieceType.Queen, color);
            board[row, 4] = CreatePiece(PieceType.King, color); board[row, 5] = CreatePiece(PieceType.Bishop, color);
            board[row, 6] = CreatePiece(PieceType.Knight, color); board[row, 7] = CreatePiece(PieceType.Rook, color);
        }

        //yeni taş oluşturma yardımcısı
        static Piece CreatePiece(PieceType type, PieceColor color)
        {
            Piece p; p.Type = type; p.Color = color; p.HasMoved = false;
            switch (type) { case PieceType.King: p.Symbol = 'K'; break; case PieceType.Queen: p.Symbol = 'Q'; break; case PieceType.Rook: p.Symbol = 'R'; break; case PieceType.Bishop: p.Symbol = 'B'; break; case PieceType.Knight: p.Symbol = 'N'; break; case PieceType.Pawn: p.Symbol = 'P'; break; default: p.Symbol = ' '; break; }
            return p;
        }

        //tahtayı konsola çizen fonksiyon (GÜNCELLENDİ: Hamle geçmişi eklendi)
        static void DrawBoard()
        {
            Console.WriteLine("    a  b  c  d  e  f  g  h        HAMLE GEÇMİŞİ");
            Console.WriteLine("  +------------------------+      -------------");
            for (int r = 0; r < 8; r++)
            {
                Console.Write((8 - r) + " |"); //satır numarası (8'den 1'e)
                for (int c = 0; c < 8; c++)
                {
                    //zemin rengi ayarı (satranç deseni)
                    if ((r + c) % 2 == 0) Console.BackgroundColor = ConsoleColor.Gray; else Console.BackgroundColor = ConsoleColor.DarkGray;

                    Piece p = board[r, c];
                    //taş rengi ayarı
                    if (p.Color == PieceColor.White) Console.ForegroundColor = ConsoleColor.Blue;
                    else if (p.Color == PieceColor.Black) Console.ForegroundColor = ConsoleColor.Red;
                    else Console.ForegroundColor = ConsoleColor.Black;

                    Console.Write(" " + p.Symbol + " ");
                }
                //satır sonu resetleme
                Console.BackgroundColor = ConsoleColor.Black; Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write("| " + (8 - r));

                // SAĞ TARAFA HAMLE LİSTESİNİ YAZDIRMA
                // 8 satırımız var, son 16 hamleyi (8 çift) gösterebiliriz
                // Önceki hamlelere erişmek için biraz matematik
                int historyStart = Math.Max(0, moveHistory.Count - 16);
                int moveIndexForThisRow = historyStart + (r * 2);

                Console.ResetColor();
                Console.Write("      "); // Boşluk

                if (moveIndexForThisRow < moveHistory.Count)
                {
                    int moveNumber = (moveIndexForThisRow / 2) + 1;
                    Console.Write($"{moveNumber}. {moveHistory[moveIndexForThisRow]}");

                    if (moveIndexForThisRow + 1 < moveHistory.Count)
                    {
                        Console.Write($" {moveHistory[moveIndexForThisRow + 1]}");
                    }
                }

                Console.WriteLine();
            }
            Console.WriteLine("  +------------------------+");
            Console.WriteLine("    a  b  c  d  e  f  g  h");
        }
    }
}