--
-- PostgreSQL database dump
--

\restrict fuv16TfbNQGWJAb8Sj7QE3ObWF1mf9MdWFfpNrYjjGZM1VpkoS4nJWbzgy5lZf1

-- Dumped from database version 18.1
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'SQL_ASCII';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: fn_checkstockavailability(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_checkstockavailability() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    current_stock INT;
BEGIN
    --get current stock level
    SELECT StockQuantity INTO current_stock FROM Products WHERE ProductID = NEW.ProductID;

    --check if requested quantity is available
    IF current_stock < NEW.Quantity THEN
        RAISE EXCEPTION 'Insufficient stock! Available: %, Requested: %', current_stock, NEW.Quantity;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_checkstockavailability() OWNER TO postgres;

--
-- Name: fn_decreasestock(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_decreasestock() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE Products
    SET StockQuantity = StockQuantity - NEW.Quantity
    WHERE ProductID = NEW.ProductID;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_decreasestock() OWNER TO postgres;

--
-- Name: fn_gettotalsalesbymonth(integer, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_gettotalsalesbymonth(p_month integer, p_year integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    total_sales DECIMAL(10, 2);
BEGIN
    SELECT COALESCE(SUM(TotalAmount), 0) INTO total_sales
    FROM Orders
    WHERE EXTRACT(MONTH FROM OrderDate) = p_Month
      AND EXTRACT(YEAR FROM OrderDate) = p_Year;

    RETURN total_sales;
END;
$$;


ALTER FUNCTION public.fn_gettotalsalesbymonth(p_month integer, p_year integer) OWNER TO postgres;

--
-- Name: fn_handlestockmovement(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_handlestockmovement() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.TransactionType = 'In' THEN
        UPDATE Products SET StockQuantity = StockQuantity + NEW.Quantity WHERE ProductID = NEW.ProductID;
    ELSIF NEW.TransactionType = 'Out' THEN
        UPDATE Products SET StockQuantity = StockQuantity - NEW.Quantity WHERE ProductID = NEW.ProductID;
    END IF;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_handlestockmovement() OWNER TO postgres;

--
-- Name: fn_updateordertotal(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_updateordertotal() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- recalculate the total amount for the order
    UPDATE Orders
    SET TotalAmount = (
        SELECT COALESCE(SUM(Quantity * UnitPrice), 0)
        FROM OrderDetails
        WHERE OrderID = NEW.OrderID
    )
    WHERE OrderID = NEW.OrderID;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.fn_updateordertotal() OWNER TO postgres;

--
-- Name: sp_registercustomer(character varying, character varying, character varying, character varying, text); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_registercustomer(IN p_firstname character varying, IN p_lastname character varying, IN p_email character varying, IN p_phone character varying, IN p_address text)
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_id INT;
BEGIN
    --step 1 : insert into People (Super Type)
    INSERT INTO People (FirstName, LastName, Email, Phone)
    VALUES (p_FirstName, p_LastName, p_Email, p_Phone)
    RETURNING PersonID INTO new_id;

    --step 2 : insert into Customers (Sub Type) using the same ID
    INSERT INTO Customers (CustomerID, Address)
    VALUES (new_id, p_Address);
END;
$$;


ALTER PROCEDURE public.sp_registercustomer(IN p_firstname character varying, IN p_lastname character varying, IN p_email character varying, IN p_phone character varying, IN p_address text) OWNER TO postgres;

--
-- Name: sp_registeremployee(character varying, character varying, character varying, character varying, numeric, character varying); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_registeremployee(IN p_firstname character varying, IN p_lastname character varying, IN p_email character varying, IN p_phone character varying, IN p_salary numeric, IN p_department character varying)
    LANGUAGE plpgsql
    AS $$
DECLARE
    new_id INT;
BEGIN
    --step 1 : insert into People
    INSERT INTO People (FirstName, LastName, Email, Phone)
    VALUES (p_FirstName, p_LastName, p_Email, p_Phone)
    RETURNING PersonID INTO new_id;

    --step 2 : insert into Employees
    INSERT INTO Employees (EmployeeID, Salary, Department)
    VALUES (new_id, p_Salary, p_Department);
END;
$$;


ALTER PROCEDURE public.sp_registeremployee(IN p_firstname character varying, IN p_lastname character varying, IN p_email character varying, IN p_phone character varying, IN p_salary numeric, IN p_department character varying) OWNER TO postgres;

--
-- Name: sp_updateproductprice(integer, numeric); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.sp_updateproductprice(IN p_productid integer, IN p_newprice numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF p_NewPrice < 0 THEN
        RAISE EXCEPTION 'Price cannot be negative!';
    END IF;

    UPDATE Products
    SET Price = p_NewPrice
    WHERE ProductID = p_ProductID;
END;
$$;


ALTER PROCEDURE public.sp_updateproductprice(IN p_productid integer, IN p_newprice numeric) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categories (
    categoryid integer NOT NULL,
    categoryname character varying(50) NOT NULL,
    description text
);


ALTER TABLE public.categories OWNER TO postgres;

--
-- Name: categories_categoryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categories_categoryid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_categoryid_seq OWNER TO postgres;

--
-- Name: categories_categoryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categories_categoryid_seq OWNED BY public.categories.categoryid;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customerid integer NOT NULL,
    address text,
    balance numeric(10,2) DEFAULT 0,
    personid integer
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    employeeid integer NOT NULL,
    salary numeric(10,2) DEFAULT 17002,
    department character varying(50),
    hiredate date DEFAULT CURRENT_DATE,
    personid integer,
    CONSTRAINT employees_salary_check CHECK ((salary >= (17002)::numeric))
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- Name: orderdetails; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orderdetails (
    detailid integer NOT NULL,
    orderid integer NOT NULL,
    productid integer NOT NULL,
    quantity integer NOT NULL,
    unitprice numeric(10,2) NOT NULL,
    CONSTRAINT orderdetails_quantity_check CHECK ((quantity > 0))
);


ALTER TABLE public.orderdetails OWNER TO postgres;

--
-- Name: orderdetails_detailid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orderdetails_detailid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orderdetails_detailid_seq OWNER TO postgres;

--
-- Name: orderdetails_detailid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orderdetails_detailid_seq OWNED BY public.orderdetails.detailid;


--
-- Name: orders; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orders (
    orderid integer NOT NULL,
    orderdate date DEFAULT CURRENT_DATE,
    totalamount numeric(10,2) DEFAULT 0,
    customerid integer NOT NULL,
    employeeid integer,
    CONSTRAINT orders_orderdate_check CHECK ((orderdate <= CURRENT_DATE))
);


ALTER TABLE public.orders OWNER TO postgres;

--
-- Name: orders_orderid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orders_orderid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orders_orderid_seq OWNER TO postgres;

--
-- Name: orders_orderid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orders_orderid_seq OWNED BY public.orders.orderid;


--
-- Name: people; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.people (
    personid integer NOT NULL,
    firstname character varying(50) NOT NULL,
    lastname character varying(50) NOT NULL,
    email character varying(100),
    phone character varying(50)
);


ALTER TABLE public.people OWNER TO postgres;

--
-- Name: people_personid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.people_personid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.people_personid_seq OWNER TO postgres;

--
-- Name: people_personid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.people_personid_seq OWNED BY public.people.personid;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    productid integer NOT NULL,
    productname character varying(100) NOT NULL,
    price numeric(10,2) NOT NULL,
    stockquantity integer DEFAULT 0,
    criticalstocklevel integer DEFAULT 10,
    categoryid integer NOT NULL,
    supplierid integer NOT NULL,
    CONSTRAINT products_price_check CHECK ((price >= (0)::numeric)),
    CONSTRAINT products_stockquantity_check CHECK ((stockquantity >= 0))
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_productid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_productid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_productid_seq OWNER TO postgres;

--
-- Name: products_productid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_productid_seq OWNED BY public.products.productid;


--
-- Name: stockmovements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stockmovements (
    movementid integer NOT NULL,
    productid integer NOT NULL,
    warehouseid integer NOT NULL,
    transactiontype character varying(10),
    quantity integer NOT NULL,
    transactiondate timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT stockmovements_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT stockmovements_transactiontype_check CHECK (((transactiontype)::text = ANY ((ARRAY['In'::character varying, 'Out'::character varying])::text[])))
);


ALTER TABLE public.stockmovements OWNER TO postgres;

--
-- Name: stockmovements_movementid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stockmovements_movementid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stockmovements_movementid_seq OWNER TO postgres;

--
-- Name: stockmovements_movementid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stockmovements_movementid_seq OWNED BY public.stockmovements.movementid;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.suppliers (
    supplierid integer NOT NULL,
    companyname character varying(100) NOT NULL,
    contactname character varying(50),
    phone character varying(50),
    taxnumber character varying(20) NOT NULL,
    address text
);


ALTER TABLE public.suppliers OWNER TO postgres;

--
-- Name: suppliers_supplierid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.suppliers_supplierid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.suppliers_supplierid_seq OWNER TO postgres;

--
-- Name: suppliers_supplierid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.suppliers_supplierid_seq OWNED BY public.suppliers.supplierid;


--
-- Name: warehouses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.warehouses (
    warehouseid integer NOT NULL,
    warehousename character varying(50) NOT NULL,
    location character varying(100),
    capacity integer,
    CONSTRAINT warehouses_capacity_check CHECK ((capacity > 0))
);


ALTER TABLE public.warehouses OWNER TO postgres;

--
-- Name: warehouses_warehouseid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.warehouses_warehouseid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.warehouses_warehouseid_seq OWNER TO postgres;

--
-- Name: warehouses_warehouseid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.warehouses_warehouseid_seq OWNED BY public.warehouses.warehouseid;


--
-- Name: categories categoryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories ALTER COLUMN categoryid SET DEFAULT nextval('public.categories_categoryid_seq'::regclass);


--
-- Name: orderdetails detailid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orderdetails ALTER COLUMN detailid SET DEFAULT nextval('public.orderdetails_detailid_seq'::regclass);


--
-- Name: orders orderid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders ALTER COLUMN orderid SET DEFAULT nextval('public.orders_orderid_seq'::regclass);


--
-- Name: people personid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.people ALTER COLUMN personid SET DEFAULT nextval('public.people_personid_seq'::regclass);


--
-- Name: products productid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN productid SET DEFAULT nextval('public.products_productid_seq'::regclass);


--
-- Name: stockmovements movementid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stockmovements ALTER COLUMN movementid SET DEFAULT nextval('public.stockmovements_movementid_seq'::regclass);


--
-- Name: suppliers supplierid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN supplierid SET DEFAULT nextval('public.suppliers_supplierid_seq'::regclass);


--
-- Name: warehouses warehouseid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses ALTER COLUMN warehouseid SET DEFAULT nextval('public.warehouses_warehouseid_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categories (categoryid, categoryname, description) FROM stdin;
1	Electronics	Smartphones, Laptops, and Tablets
2	Clothing	Men and Women Fashion Apparels
3	Stationery	Office Supplies, Books, and Paper Products
4	Home & Living	Small Appliances and Home Decoration
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customerid, address, balance, personid) FROM stdin;
\.


--
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (employeeid, salary, department, hiredate, personid) FROM stdin;
\.


--
-- Data for Name: orderdetails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orderdetails (detailid, orderid, productid, quantity, unitprice) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orders (orderid, orderdate, totalamount, customerid, employeeid) FROM stdin;
\.


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.people (personid, firstname, lastname, email, phone) FROM stdin;
1	Alice	Johnson	alice.johnson@company.com	555-111-2233
2	Bob	Williams	bob.williams@company.com	555-444-5566
3	Charlie	Davis	charlie.davis@gmail.com	533-999-8877
4	Diana	Miller	diana.miller@hotmail.com	542-777-6655
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.products (productid, productname, price, stockquantity, criticalstocklevel, categoryid, supplierid) FROM stdin;
1	iPhone 15 Pro	1200.00	50	10	1	1
3	Samsung Galaxy S24	1100.00	45	10	1	1
4	Denim Jeans	45.00	200	20	2	2
5	Basic Cotton T-Shirt	15.00	500	50	2	2
6	Hardcover Notebook	8.50	1000	100	3	3
7	Fountain Pen Set	25.00	300	50	3	3
2	MacBook Air M2	150000.00	1	5	1	1
\.


--
-- Data for Name: stockmovements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stockmovements (movementid, productid, warehouseid, transactiontype, quantity, transactiondate) FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.suppliers (supplierid, companyname, contactname, phone, taxnumber, address) FROM stdin;
1	TechGlobal Inc.	John Doe	+1 555 010 1010	TAX123456789	Silicon Valley, CA, USA
2	FashionTex Ltd.	Jane Smith	+44 20 7946 0000	TAX987654321	Oxford Street, London, UK
3	OfficeWorld Corp.	Robert Brown	+1 212 555 1234	TAX456123789	Manhattan, NY, USA
\.


--
-- Data for Name: warehouses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.warehouses (warehouseid, warehousename, location, capacity) FROM stdin;
1	Central Warehouse	Main Logistics Hub, Industrial Zone	10000
2	North Branch	Downtown Distribution Center	500
3	South Branch	Airport Cargo Area	300
\.


--
-- Name: categories_categoryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categories_categoryid_seq', 5, true);


--
-- Name: orderdetails_detailid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orderdetails_detailid_seq', 2, true);


--
-- Name: orders_orderid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orders_orderid_seq', 2, true);


--
-- Name: people_personid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.people_personid_seq', 4, true);


--
-- Name: products_productid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_productid_seq', 7, true);


--
-- Name: stockmovements_movementid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stockmovements_movementid_seq', 1, true);


--
-- Name: suppliers_supplierid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.suppliers_supplierid_seq', 3, true);


--
-- Name: warehouses_warehouseid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.warehouses_warehouseid_seq', 3, true);


--
-- Name: categories categories_categoryname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_categoryname_key UNIQUE (categoryname);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (categoryid);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customerid);


--
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (employeeid);


--
-- Name: orderdetails orderdetails_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orderdetails
    ADD CONSTRAINT orderdetails_pkey PRIMARY KEY (detailid);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (orderid);


--
-- Name: people people_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_email_key UNIQUE (email);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_pkey PRIMARY KEY (personid);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (productid);


--
-- Name: products products_productname_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_productname_key UNIQUE (productname);


--
-- Name: stockmovements stockmovements_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stockmovements
    ADD CONSTRAINT stockmovements_pkey PRIMARY KEY (movementid);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (supplierid);


--
-- Name: suppliers suppliers_taxnumber_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_taxnumber_key UNIQUE (taxnumber);


--
-- Name: warehouses warehouses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.warehouses
    ADD CONSTRAINT warehouses_pkey PRIMARY KEY (warehouseid);


--
-- Name: orderdetails trg_checkstockbeforeinsert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_checkstockbeforeinsert BEFORE INSERT ON public.orderdetails FOR EACH ROW EXECUTE FUNCTION public.fn_checkstockavailability();


--
-- Name: orderdetails trg_decreasestockafterinsert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_decreasestockafterinsert AFTER INSERT ON public.orderdetails FOR EACH ROW EXECUTE FUNCTION public.fn_decreasestock();


--
-- Name: stockmovements trg_stockmovementupdate; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_stockmovementupdate AFTER INSERT ON public.stockmovements FOR EACH ROW EXECUTE FUNCTION public.fn_handlestockmovement();


--
-- Name: orderdetails trg_updatetotalafterdetail; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_updatetotalafterdetail AFTER INSERT ON public.orderdetails FOR EACH ROW EXECUTE FUNCTION public.fn_updateordertotal();


--
-- Name: customers fk_customer_person; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT fk_customer_person FOREIGN KEY (customerid) REFERENCES public.people(personid) ON DELETE CASCADE;


--
-- Name: customers fk_customers_people; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT fk_customers_people FOREIGN KEY (personid) REFERENCES public.people(personid);


--
-- Name: orderdetails fk_detail_order; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orderdetails
    ADD CONSTRAINT fk_detail_order FOREIGN KEY (orderid) REFERENCES public.orders(orderid) ON DELETE CASCADE;


--
-- Name: orderdetails fk_detail_product; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orderdetails
    ADD CONSTRAINT fk_detail_product FOREIGN KEY (productid) REFERENCES public.products(productid);


--
-- Name: employees fk_employee_person; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employee_person FOREIGN KEY (employeeid) REFERENCES public.people(personid) ON DELETE CASCADE;


--
-- Name: employees fk_employees_people; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT fk_employees_people FOREIGN KEY (personid) REFERENCES public.people(personid);


--
-- Name: stockmovements fk_movement_product; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stockmovements
    ADD CONSTRAINT fk_movement_product FOREIGN KEY (productid) REFERENCES public.products(productid);


--
-- Name: stockmovements fk_movement_warehouse; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stockmovements
    ADD CONSTRAINT fk_movement_warehouse FOREIGN KEY (warehouseid) REFERENCES public.warehouses(warehouseid);


--
-- Name: orders fk_order_customer; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_order_customer FOREIGN KEY (customerid) REFERENCES public.customers(customerid);


--
-- Name: orders fk_order_employee; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT fk_order_employee FOREIGN KEY (employeeid) REFERENCES public.employees(employeeid);


--
-- Name: products fk_product_category; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_product_category FOREIGN KEY (categoryid) REFERENCES public.categories(categoryid);


--
-- Name: products fk_product_supplier; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT fk_product_supplier FOREIGN KEY (supplierid) REFERENCES public.suppliers(supplierid);


--
-- PostgreSQL database dump complete
--

\unrestrict fuv16TfbNQGWJAb8Sj7QE3ObWF1mf9MdWFfpNrYjjGZM1VpkoS4nJWbzgy5lZf1

