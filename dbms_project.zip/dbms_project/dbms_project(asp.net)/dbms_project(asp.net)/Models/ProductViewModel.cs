﻿namespace dbms_project_asp.net_.Models
{
    public class ProductViewModel
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public int StockQuantity { get; set; }
        public string CategoryName { get; set; } // For display
        public string SupplierName { get; set; } // For display
    }
}
