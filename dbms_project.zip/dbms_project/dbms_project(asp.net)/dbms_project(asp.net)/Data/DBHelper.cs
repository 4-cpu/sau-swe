﻿using Npgsql;
using System.Data;
namespace dbms_project_asp.net_.Data
{
    public class DBHelper
    {
        private readonly string _connectionString;

        public DBHelper(IConfiguration configuration)
        {
            // reads connection infos from appsettings.json
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        // creates new connection from database and gives to us
        public NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(_connectionString);
        }
    }
}
