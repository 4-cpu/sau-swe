﻿using System.Collections.Generic;
using dbms_project_asp.net_.Data;
using dbms_project_asp.net_.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Npgsql;

namespace StokTakipWeb.Controllers
{
    public class ProductController : Controller
    {
        private readonly DBHelper _db;

        public ProductController(DBHelper db)
        {
            _db = db;
        }

        public IActionResult Index(string searchString)
        {
            var productList = new List<ProductViewModel>();

            using (var connection = _db.GetConnection())
            {
                connection.Open();

                //basic sql query
                string sql = @"
            SELECT p.ProductID, p.ProductName, p.Price, p.StockQuantity, 
                   c.CategoryName, s.CompanyName AS SupplierName
            FROM Products p
            JOIN Categories c ON p.CategoryID = c.CategoryID
            JOIN Suppliers s ON p.SupplierID = s.SupplierID";

                // add filter if search has started
                if (!string.IsNullOrEmpty(searchString))
                {
                    //ILIKE searches without case sensitivity
                    sql += " WHERE p.ProductName ILIKE @search";
                }

                sql += " ORDER BY p.ProductID";

                using (var command = new NpgsqlCommand(sql, connection))
                {
                    if (!string.IsNullOrEmpty(searchString))
                    {
                        // Arama kelimesinin başına ve sonuna % koyuyoruz ki içinde geçenleri bulsun
                        command.Parameters.AddWithValue("@search", "%" + searchString + "%");
                    }

                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var product = new ProductViewModel
                            {
                                ProductID = reader.GetInt32(reader.GetOrdinal("ProductID")),
                                ProductName = reader.GetString(reader.GetOrdinal("ProductName")),
                                Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                StockQuantity = reader.GetInt32(reader.GetOrdinal("StockQuantity")),
                                CategoryName = reader.GetString(reader.GetOrdinal("CategoryName")),
                                SupplierName = reader.GetString(reader.GetOrdinal("SupplierName"))
                            };
                            productList.Add(product);
                        }
                    }
                }
            }

            return View(productList);
        }

        //opening page
        [HttpGet]
        public IActionResult Create()
        {
            //we need to pull categories and suppliers for dropdown menu
            //because user can not enter id

            var categories = new List<SelectListItem>();
            var suppliers = new List<SelectListItem>();

            using (var connection = _db.GetConnection())
            {
                connection.Open();

                //pull categories
                using (var cmd = new NpgsqlCommand("SELECT CategoryID, CategoryName FROM Categories", connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new SelectListItem
                        {
                            Value = reader["CategoryID"].ToString(),
                            Text = reader["CategoryName"].ToString()
                        });
                    }
                }

                //pull suppliers
                using (var cmd = new NpgsqlCommand("SELECT SupplierID, CompanyName FROM Suppliers", connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        suppliers.Add(new SelectListItem
                        {
                            Value = reader["SupplierID"].ToString(),
                            Text = reader["CompanyName"].ToString()
                        });
                    }
                }
            }

            //take lists to the page
            ViewBag.Categories = categories;
            ViewBag.Suppliers = suppliers;

            return View();
        }

        //saving
        [HttpPost]
        public IActionResult Create(ProductViewModel model)
        {
            try
            {
                using (var connection = _db.GetConnection())
                {
                    connection.Open();

                    // SQL INSERT Komutu (Güvenlik için parametreli yazdım)
                    string sql = @"
                INSERT INTO Products (ProductName, Price, StockQuantity, CategoryID, SupplierID) 
                VALUES (@name, @price, @stock, @catId, @supId)";

                    using (var command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", model.ProductName);
                        command.Parameters.AddWithValue("@price", model.Price);
                        command.Parameters.AddWithValue("@stock", model.StockQuantity);

                        // We convert the IDs coming from the form to integers before adding them.
                        // On the View side, these values may come as strings; the model binder handles this, but be careful.
                        // Here, we simply take them from the model.
                        // Note: Values selected from dropdowns should come as IDs instead of model.CategoryName and SupplierName.
                        // But for simplicity, we will directly get them by using name='CategoryID' in the View.
                        // Therefore, we will add SQL parameters manually:

                        // We can also get the data from Request; this is the most reliable way.

                        int catId = int.Parse(Request.Form["CategoryID"]);
                        int supId = int.Parse(Request.Form["SupplierID"]);

                        command.Parameters.AddWithValue("@catId", catId);
                        command.Parameters.AddWithValue("@supId", supId);

                        command.ExecuteNonQuery();
                    }
                }

                //come back to the list if these codes are successful
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                //show the error if exist
                ViewBag.Error = "Error adding product: " + ex.Message;
                return Create(); //return form again
            }
        }
        
        //delete
        public IActionResult Delete(int id)
        {
            try
            {
                using (var connection = _db.GetConnection())
                {
                    connection.Open();
                    // SQL DELETE 
                    string sql = "DELETE FROM Products WHERE ProductID = @id";

                    using (var command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                // if there is an error
                object? v = TempData["Error"];
            }

            // return to list if it couldnt delete either
            return RedirectToAction("Index");
        }
       

        //update page
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ProductViewModel product = null;

            // firstly pull the product from database
            using (var connection = _db.GetConnection())
            {
                connection.Open();
                string sql = "SELECT * FROM Products WHERE ProductID = @id";

                using (var command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", id);
                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            product = new ProductViewModel
                            {
                                ProductID = reader.GetInt32(reader.GetOrdinal("ProductID")),
                                ProductName = reader.GetString(reader.GetOrdinal("ProductName")),
                                Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                StockQuantity = reader.GetInt32(reader.GetOrdinal("StockQuantity")),
                                // To have the dropdown pre-selected, it's enough to take only the IDs (they will match on the View side).
                                // Our model didn't have int CategoryID, but we could pass it via ViewBag or add it to the model.
                                // Quick solution: let's put these IDs into the ViewBag so we can mark "selected" on the View side.

                            };
                            ViewBag.SelectedCategoryID = reader.GetInt32(reader.GetOrdinal("CategoryID"));
                            ViewBag.SelectedSupplierID = reader.GetInt32(reader.GetOrdinal("SupplierID"));
                        }
                    }
                }

                // For the 2nd dropdowns, we still need to fetch the Category and Supplier lists (like in Create).
                // (Here, to run a new query without closing the connection, the previous reader must have finished its job; thankfully, the using block takes care of that.)


                var categories = new List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem>();
                using (var cmd = new NpgsqlCommand("SELECT CategoryID, CategoryName FROM Categories", connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        categories.Add(new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                        {
                            Value = reader["CategoryID"].ToString(),
                            Text = reader["CategoryName"].ToString()
                        });
                    }
                }
                ViewBag.Categories = categories;

                var suppliers = new List<Microsoft.AspNetCore.Mvc.Rendering.SelectListItem>();
                using (var cmd = new NpgsqlCommand("SELECT SupplierID, CompanyName FROM Suppliers", connection))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        suppliers.Add(new Microsoft.AspNetCore.Mvc.Rendering.SelectListItem
                        {
                            Value = reader["SupplierID"].ToString(),
                            Text = reader["CompanyName"].ToString()
                        });
                    }
                }
                ViewBag.Suppliers = suppliers;
            }

            if (product == null) return NotFound(); // return error if product couldnt be found.

            return View(product);
        }

        //update
        [HttpPost]
        public IActionResult Edit(ProductViewModel model)
        {
            try
            {
                using (var connection = _db.GetConnection())
                {
                    connection.Open();
                    // SQL UPDATE 
                    string sql = @"
                UPDATE Products 
                SET ProductName=@name, Price=@price, StockQuantity=@stock, CategoryID=@catId, SupplierID=@supId 
                WHERE ProductID=@id";

                    using (var command = new NpgsqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", model.ProductName);
                        command.Parameters.AddWithValue("@price", model.Price);
                        command.Parameters.AddWithValue("@stock", model.StockQuantity);

                        // taking values from dropdown
                        int catId = int.Parse(Request.Form["CategoryID"]);
                        int supId = int.Parse(Request.Form["SupplierID"]);

                        command.Parameters.AddWithValue("@catId", catId);
                        command.Parameters.AddWithValue("@supId", supId);
                        command.Parameters.AddWithValue("@id", model.ProductID); // for knowing the which product that we will update5

                        command.ExecuteNonQuery();
                    }
                }
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                ViewBag.Error = "Error updating product: " + ex.Message;
                return View(model);
            }
        }
    }
}