using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace dbms_project_asp.net_.Views.Product
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
